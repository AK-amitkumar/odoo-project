# -*- coding: utf-8 -*-
from . import production_lot_detail
