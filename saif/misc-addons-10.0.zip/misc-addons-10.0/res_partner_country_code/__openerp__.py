# -*- coding: utf-8 -*-
{
    'name': "Auto-fill partner's country by top-lever domain of email address",
    'version': '1.0',
    'author': "IT-Projects LLC, Ivan Yelizariev",
    'license': 'LGPL-3',
    'website': "https://yelizariev.github.io",
    'category': 'Tools',
    'depends': ['base'],
    'data': ['views.xml'],
    'demo': [],
    'installable': False,
}
