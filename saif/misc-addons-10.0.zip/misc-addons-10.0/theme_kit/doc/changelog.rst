`1.0.2`
-------

- ADD: added new styles for calendar


`1.0.1`
-------

- FIX: compatibility with Enterprise version


`1.0.0`
-------

- Init version
