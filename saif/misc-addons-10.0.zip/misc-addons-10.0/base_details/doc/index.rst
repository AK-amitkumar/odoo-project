==============
 Base Details
==============

Installation
============

* `Install <https://odoo-development.readthedocs.io/en/latest/odoo/usage/install-module.html>`__ this module in a usual way

Usage
=====

You can find example of usage in the module ``product_details`` https://apps.odoo.com/apps/modules/10.0/product_details/
