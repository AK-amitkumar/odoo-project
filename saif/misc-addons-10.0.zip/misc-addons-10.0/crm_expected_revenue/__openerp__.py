# -*- coding: utf-8 -*-
{
    'name': "Multiply  expected revenue by probability",
    'version': '9.0.1.0.0',
    'author': 'IT-Projects LLC, Ivan Yelizariev',
    'license': 'LGPL-3',
    'category': 'Custom',
    'website': 'https://yelizariev.github.io',
    'depends': ['crm'],
    'data': [
        'views.xml',
    ],
    'installable': True
}
