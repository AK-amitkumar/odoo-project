Multiply  expected revenue by probability
=========================================

The module update Expected Revenue value in opportunities kanban view.

Tested on Odoo 8.0 ea60fed97af1c139e4647890bf8f68224ea1665b
