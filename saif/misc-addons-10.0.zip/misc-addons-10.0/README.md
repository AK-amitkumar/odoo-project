Odoo addons
===========

Miscellaneous modules for Odoo.

List of repositories:
---------------------

* https://github.com/it-projects-llc/misc-addons
* https://github.com/it-projects-llc/pos-addons
* https://github.com/it-projects-llc/mail-addons
* https://github.com/it-projects-llc/rental-addons
* https://github.com/it-projects-llc/access-addons
* https://github.com/it-projects-llc/website-addons
* https://github.com/it-projects-llc/l10n-addons
* https://github.com/it-projects-llc/odoo-telegram
* https://github.com/it-projects-llc/odoo-saas-tools


Donation
========
Feel free to support our efforts by purchasing [our modules at app store](https://apps.odoo.com/apps/modules/browse?price=Paid&order=Newest&author=IT-Projects+LLC)
