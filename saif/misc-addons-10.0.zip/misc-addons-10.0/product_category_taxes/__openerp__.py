{
    'name': 'Product Category Taxes',
    'version': '1.0.0',
    'author': 'IT-Projects LLC, Ivan Yelizariev',
    'summary': 'Adding taxes into product category',
    'license': 'LGPL-3',
    'category': 'Accounting & Finance',
    'website': 'https://it-projects.info',
    'depends': ['account'],
    'data': ['views.xml'],
    'demo': [],
    'installable': True,
}
