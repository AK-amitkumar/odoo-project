Log\Notify Next Action changes
==============================

Description: https://apps.odoo.com/apps/modules/9.0/crm_next_action/

Tested on Odoo 9.0 bc0986f53bc03bb958f3acce10ec23805afb7b6a
