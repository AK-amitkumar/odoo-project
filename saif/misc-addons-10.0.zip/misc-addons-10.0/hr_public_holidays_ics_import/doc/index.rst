====================
 Import Holiday ICS
====================


Usage
=====

* From ``Human Resources / Configuration / Public Holidays`` select ``Calendar Year``
* Click ``[Import from ics]`` button, select the file, click ``[Import]``
