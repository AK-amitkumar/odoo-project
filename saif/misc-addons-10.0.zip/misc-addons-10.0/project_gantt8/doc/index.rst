=========================
 Gantt view for Projects
=========================

Installation
============

Nothing special is needed to install this module.

Usage
=====

* Open ``Project / Task``
* Switch to Gantt view via icons in top right-hand

Uninstallation
==============

Nothing special is needed to uninstall this module.
