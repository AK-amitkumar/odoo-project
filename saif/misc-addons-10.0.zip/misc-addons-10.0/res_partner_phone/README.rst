Phone and mobile in display_name for searching
==============================================


Tested on Odoo 8.0 e84c01ebc1ef4fdf99865c45f10d7b6b4c4de229
