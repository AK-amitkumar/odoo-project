`1.0.1`
-------

- **FIX:** Error in some specific environment (browser or third-party module)

`1.0.0`
-------

- Init version
