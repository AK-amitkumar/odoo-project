Shows customer's name and country flag at project kanban view.

Also, add customer name at project field, e.g. at Task
form. Technically, the module redefine name_get function.

Tested on Odoo 8.0 d023c079ed86468436f25da613bf486a4a17d625
