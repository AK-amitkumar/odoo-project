==============
 Time Tracker
==============

The timer:

* allows to track the user working time
* helps to control and see the overall working load during a day/week
* generates the corresponding worktime reports

It is a great solution that could be as alternative to Hubstaff or other work time tracker app.

Credits
=======

Contributors
------------
* Dinar Gabbasov <gabbasov@it-projects.info>

Sponsors
--------
* `IT-Projects LLC <https://it-projects.info>`_

Further information
===================

Demo: http://runbot.it-projects.info/demo/misc-addons/8.0

HTML Description: https://apps.odoo.com/apps/modules/8.0/project_timelog/

Usage instructions: `<doc/index.rst>`_

Changelog: `<doc/changelog.rst>`_

Tested on Odoo 8.0 6a1ecef7759dd72d30d23fe1c55966e1a97bac01
