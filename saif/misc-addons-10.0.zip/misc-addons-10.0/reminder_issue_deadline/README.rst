Reminders and Agenda for issues
==============================

Based on the reminder series of modules by Ivan Yelizariev. Adds the reminder action to project issues based on
deadline date. Depends on https://github.com/OCA/project-service/tree/8.0/service_desk_issue.
