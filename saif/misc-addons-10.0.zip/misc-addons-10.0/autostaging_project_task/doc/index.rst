==========================
 Autostaging project task
==========================

Installation
============

* `Install <https://odoo-development.readthedocs.io/en/latest/odoo/usage/install-module.html>`__ this module in a usual way

Configuration
=============

Does not require pre-configuration

Usage
=====

* Open menu ``Project >> Configuration >> Stages``
* Choose a stage which position you want to change automatically after an established time
* Click on ``[Edit]``
* Mark the "Autostaging enabled"
* Select the necessary next stage
* Specify "Autostaging idle timeout" (days)
* Click on ``[Save]``
