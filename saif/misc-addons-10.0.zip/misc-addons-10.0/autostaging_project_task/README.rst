Autostaging project task
=========================

Change stages of tasks automatically after a specified time

Credits
=======

Contributors
------------
* Ildar Nasyrov <iledarn@it-projects.info>

Sponsors
--------
* `IT-Projects LLC <https://it-projects.info>`__

Maintainers
-----------
* `IT-Projects LLC <https://it-projects.info>`__

Further information
===================

Demo: http://runbot.it-projects.info/demo/misc-addons/10.0

HTML Description: https://apps.odoo.com/apps/modules/10.0/autostaging_project_task/

Usage instructions: `<doc/index.rst>`_

Changelog: `<doc/changelog.rst>`_

Tested on Odoo 10.0 87184d0894fdb7444cc0d4b6e7028f1f97a7c4f7
