# -*- coding: utf-8 -*-
{
    'name': "Automatically move tasks",
    'author': "IT-Projects LLC, Ivan Yelizariev",
    'license': 'LGPL-3',
    'website': "https://yelizariev.github.io",
    'category': 'Project',
    'version': '1.0.0',
    'depends': ['project'],
    'data': [
        'views.xml',
        'data.xml',
    ],
    'installable': False
}
