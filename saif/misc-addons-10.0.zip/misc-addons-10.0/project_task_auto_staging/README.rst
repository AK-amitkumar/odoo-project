Automatically move tasks
=========================

Move tasks from one stage to another after some days of non-use.

Settings:

* The stages for auto move may by defined at 'Project\\Configuration\\Stages\\Task Stages'.
* Enable/disable auto moving tasks in the project.
* Time of Cron job can be configured at 'Settings\\Automation\\Scheduled Actions'.
