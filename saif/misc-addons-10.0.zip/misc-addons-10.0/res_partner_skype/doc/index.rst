=============================
 Skype field in partner form
=============================

Installation
============

* `Install <https://odoo-development.readthedocs.io/en/latest/odoo/usage/install-module.html>`__


Configuration
=============

The module does not need to be pre-configured.


Usage
=====

* As an example install CRM app
* Open ``Sales >> Customers``
* Open partner form view
* Click on ``[Edit]`` button
* Specify Skype field 
* Click on ``[Save]`` button
* On the form view click on skype address to open chat window.
