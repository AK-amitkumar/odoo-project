# -*- coding: utf-8 -*-
{
    'name': 'Custom menu bar (orange)',
    'version': '1.0.0',
    'author': 'IT-Projects LLC, Ivan Yelizariev',
    'license': 'LGPL-3',
    'category': 'Tools',
    'website': 'https://yelizariev.github.io',
    'description': """

    """,
    'depends': ['web'],
    'data': [
        'views.xml',
    ],
    'installable': False
}
