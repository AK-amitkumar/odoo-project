=======================================
 Reminders and Agenda (technical core)
=======================================

Installation
============

* `Install <https://odoo-development.readthedocs.io/en/latest/odoo/usage/install-module.html>`__ this module in a usual way

Configuration
=============

This module don't need to be configured.


Usage
=====

This is a technical module, it does not have instructions for users.

