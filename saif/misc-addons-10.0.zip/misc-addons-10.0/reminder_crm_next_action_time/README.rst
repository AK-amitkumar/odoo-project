Reminders and Agenda for Opportunities (with time)
==================================================

Description: https://apps.odoo.com/apps/modules/10.0/reminder_crm_next_action_time/

Tested on Odoo 10.0 beaea311e6becd65dbb29925ba56016d4c249a68
