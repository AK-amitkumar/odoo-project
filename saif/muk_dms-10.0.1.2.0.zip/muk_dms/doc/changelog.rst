*****
MuK Documents
*****

Version 1.2.0
########

In version 1.2.0 almost all models had been reworked, to increase performance and maintainability.

Preview
**********************

The file preview has been removed completely and is now a separate project. Therefore MuK Documents makes use
of `MuK Preview <https://github.com/muk-it/muk_web/tree/10.0/muk_web_preview/>`_ to render file previews.

* This is a bulleted list.

