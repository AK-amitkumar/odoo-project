# -*- coding: utf-8 -*-
{
    "name": "Fix mail error 553",
    "version": "0.3",
    "author": "IT-Projects LLC, Ivan Yelizariev",
    'license': 'LGPL-3',
    "category": "Discuss",
    "website": "https://yelizariev.github.io",
    "depends": ["base", "mail"],
    "data": ["data.xml"],
    'installable': False
}
