Trim email field in partner form.
