.. _changelog:

Changelog
=========

`1.0.4`
-------

- FIX: don't allow to relocate message to itself as it cause infinitive loop
- ADD: 'Move Followers' option -- Add followers of current record to a new record.

`1.0.3`
-------

- FIX email_from parsing. There was an error with specific email_from value (e.g. '"name @ example" <name@example.com>')

`1.0.2`
-------

- big improvements in interface

`1.0.1`
-------

- fix bug "some messages are not shown in inbox after relocation"
- improve "Move back" tool
