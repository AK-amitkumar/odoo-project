Mail relocation
===============

Demo: http://runbot.it-projects.info/demo/mail-addons/9.0

Description: https://www.odoo.com/apps/modules/9.0/mail_move_message/

Further information and discussion: http://yelizariev.github.io/odoo/module/2015/04/10/mail-relocation.html

Tested on Odoo 8.0 d023c079ed86468436f25da613bf486a4a17d625
