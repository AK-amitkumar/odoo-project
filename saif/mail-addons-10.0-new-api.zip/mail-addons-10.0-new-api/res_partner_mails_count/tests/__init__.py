# -*- coding: utf-8 -*-

from . import test_mail
# from . import test_phantom
