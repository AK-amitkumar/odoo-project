Fix "False" in empty email body
===============================

Description: https://apps.odoo.com/apps/modules/8.0/mail_fix_empty_body/

Tested on Odoo 8.0 ab7b5d7732a7c222a0aea45bd173742acd47242d
