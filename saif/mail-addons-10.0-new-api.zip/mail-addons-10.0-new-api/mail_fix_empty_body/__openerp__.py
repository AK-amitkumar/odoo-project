# -*- coding: utf-8 -*-
{
    'name': 'Fix "False" in empty email body',
    'version': '1.0.0',
    'author': 'IT-Projects LLC, Ivan Yelizariev',
    'license': 'LGPL-3',
    "category": "Discuss",
    'website': 'https://twitter.com/yelizariev',
    'price': 9.00,
    'currency': 'EUR',
    'depends': ['mail'],
    'data': [
    ],
    'installable': False
}
