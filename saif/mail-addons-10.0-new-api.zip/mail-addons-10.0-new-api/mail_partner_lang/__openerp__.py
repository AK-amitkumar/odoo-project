# -*- coding: utf-8 -*-
{
    'name': 'Use partner language in mail',
    'version': '1.0.0',
    'author': 'IT-Projects LLC, Ivan Yelizariev',
    'license': 'LGPL-3',
    "category": "Discuss",
    'website': 'https://yelizariev.github.io',

    'depends': ['mail'],
    'data': [],
    'installable': False,
}
