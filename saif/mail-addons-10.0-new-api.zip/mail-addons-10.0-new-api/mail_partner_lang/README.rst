Use partner language in mail
============================

FIXME: there is issue with frozen dict in new odoo.
