Delete Odoo footer in email
===========================

Tested on 8.0 ab7b5d7732a7c222a0aea45bd173742acd47242d
