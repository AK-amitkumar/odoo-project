# -*- coding: utf-8 -*-
{
    'name': 'Delete Odoo footer in email (TODO)',
    'version': '1.0.0',
    'author': 'IT-Projects LLC, Ivan Yelizariev',
    'license': 'LGPL-3',
    "category": "Discuss",
    'website': 'https://yelizariev.github.io',
    'depends': [],
    'data': [
    ],
    'installable': False
}
