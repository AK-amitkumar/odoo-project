==========================
 Always show reply button
==========================

The module allows to reply to any message. Out-of-box odoo shows reply button for messages attached to some record.

Further information
===================

HTML Description: https://apps.odoo.com/apps/modules/9.0/mail_reply/

Usage instructions: `<doc/index.rst>`_

Changelog: `<doc/changelog.rst>`_

Tested on Odoo 9.0 d3dd4161ad0598ebaa659fbd083457c77aa9448d
