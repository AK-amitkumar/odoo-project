===================
 Show reply button
===================

Usage
=====

* Open Discuss menu
* All messages have reply button
