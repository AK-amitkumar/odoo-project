Mark unstarred email as read, remove filter in 'To-do' folder
=============================================================
