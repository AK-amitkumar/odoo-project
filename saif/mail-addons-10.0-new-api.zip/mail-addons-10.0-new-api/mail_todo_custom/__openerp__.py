# -*- coding: utf-8 -*-
{
    'name': "Mark unstarred email as read, remove filter in 'To-do' folder",
    'version': '1.0',
    'author': 'IT-Projects LLC',
    'license': 'LGPL-3',
    'website': "https://yelizariev.github.io",
    "category": "Discuss",
    'depends': ['mail'],
    'data': ['mail_todo_custom.xml'],
    'demo': [],
    'installable': False,
}
