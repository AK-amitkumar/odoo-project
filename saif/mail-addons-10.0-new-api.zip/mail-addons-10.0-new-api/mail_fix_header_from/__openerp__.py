# -*- coding: utf-8 -*-
{
    "name": "Fix non-ascii header 'from' (OBSOLETE)",
    "version": "0.3",
    "author": "IT-Projects LLC, Ivan Yelizariev",
    'license': 'LGPL-3',
    "category": "Discuss",
    "website": "https://yelizariev.github.io",
    "description": """
Obsolete in odoo 8.0 since Sep 10, 2014 https://github.com/odoo/odoo/commit/f2cf6ced17d3477b8858e3a8f955a42cc8a629ff . You can install this module, if you use older version.
    """,
    "depends": ["base"],
    #"init_xml" : [],
    #"update_xml" : [],
    #"active": True,
    'installable': False
}
