Changelog
=========

`1.1.0`
-------

- ADD: automatic domain verification

-------
`1.0.0`
-------

- Init version
