# -*- coding: utf-8 -*-
{
    'name': "Mailgun",
    'author': "IT-Projects LLC, Ildar Nasyrov",
    'license': 'LGPL-3',
    'website': "https://twitter.com/nasyrov_ildar",
    'category': 'Discuss',
    'version': '1.1.0',
    'depends': ['mail'],
    'data': [
        'data/cron.xml',
    ],
}
