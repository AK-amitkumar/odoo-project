Sentbox
=======

Adds Sent menu, which shows sent messages

Usage
-----
Click Discuss/Sent menu -- sent messages are displayed

Further information
-------------------
Further information and discussion: https://yelizariev.github.io/odoo/module/2015/02/19/sentbox.html

HTML Description: https://apps.odoo.com/apps/modules/9.0/mail_sent/

Tested on Odoo 9.0 b9f206953e3f877adf18643f154d1262842564ee
