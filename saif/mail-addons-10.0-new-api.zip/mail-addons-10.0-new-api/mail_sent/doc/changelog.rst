.. _changelog:

Changelog
=========

`1.0.2`
-------

- FIX access issue "read access error on delete"
