Mail Archives
=============

Adds Archive menu, which shows sent/received messages

Usage
-----
Click Discuss/Archive menu -- sent/received messages are displayed

Further information
-------------------

HTML Description: https://apps.odoo.com/apps/modules/9.0/mail_archives/

Tested on Odoo 9.0 b9f206953e3f877adf18643f154d1262842564ee