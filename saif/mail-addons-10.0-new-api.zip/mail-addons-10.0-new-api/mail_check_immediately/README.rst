Check mail immediately
======================

Description: https://apps.odoo.com/apps/modules/8.0/mail_check_immediately/
