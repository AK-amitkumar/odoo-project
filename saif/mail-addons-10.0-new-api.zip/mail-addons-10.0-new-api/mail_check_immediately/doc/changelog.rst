.. _changelog:

Changelog
=========

`1.0.1`
-------

- FIX: incorrectly displayed last updated time when multiple threads (--workers)