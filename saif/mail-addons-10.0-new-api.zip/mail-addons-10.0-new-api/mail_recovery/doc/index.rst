===============
 Mail recovery
===============

Usage
=====

* Start typing new message
* Force close browser window or tab
* Click on message input
* The message is recovered
