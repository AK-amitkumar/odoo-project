===================
 Show all messages
===================

Usage
=====

* Open menu ``Discuss / All messages``
* You see all messages
