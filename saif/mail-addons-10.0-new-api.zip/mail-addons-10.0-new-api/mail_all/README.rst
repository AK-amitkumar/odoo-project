===================
 Show all messages
===================

Adds ``Discuss / All`` menu, that shows all messages accesable by current user

Further information
-------------------

HTML Description: https://apps.odoo.com/apps/modules/9.0/mail_all/

Usage instructions: `<doc/index.rst>`__

Changelog: `<doc/changelog.rst>`__

Tested on Odoo 9.0 d3dd4161ad0598ebaa659fbd083457c77aa9448d
