=========================
 Show message recipients
=========================

Usage
=====

* Open Discuss menu.
* Many messages have Recipients info.
* Click Inbox left menu item, click Send mail button, set recipient and send message. This message will show recipient.
* To see the recipient's need hover the mouse over a message.
* For messages created before install module it will not work where the recipients are not set. There is no way to restore recipients value.
