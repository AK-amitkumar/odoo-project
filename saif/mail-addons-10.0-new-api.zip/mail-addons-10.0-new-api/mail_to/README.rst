=========================
 Show message recipients
=========================

Allows you be sure, that all discussion participants were notified. Adds recipients label the right of message.

Further information
-------------------
HTML Description: https://apps.odoo.com/apps/modules/9.0/mail_to/

Tested on Odoo 9.0 d3dd4161ad0598ebaa659fbd083457c77aa9448d
