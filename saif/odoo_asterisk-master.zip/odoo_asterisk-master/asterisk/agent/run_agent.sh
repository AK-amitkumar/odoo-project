#!/bin/sh

cd /opt/agent
exec python asterisk_helper.py
