==============================
 Debt/Credit notebook for POS
==============================

Installation
============

If you have open POS session after install the module close it and open new one.
After this a debt payment method will appear in the POS.

Usage
=====

Debt Journal
------------

* open POS
* add usual products
* select Customer
* on payment screen use "Debt Journal" to pay

Credit Products
---------------

* Instead of using Debt Journal, customer can purchase *Credits* via *Credit Products*
* When you create *Credit product*, don't forget to set **Credit Product** field
* *Credit products* can be sold via POS and via invoices (including eCommerce). The later requires `another module <https://apps.odoo.com/apps/modules/10.0/pos_debt_notebook_sync/>`_ to notify POS about eCommerce sales, otherwise POS will get updates about invoices only after POS reloading.
* Note. Taxes on purchasing *Credit Products* are not supported. Taxes are applied on purchasings normal products.

Manual Credit Updates
---------------------

It can be used for different purposes:

* to setup initial debt / credit values
* for periodic import from another system
* to remove test debts

To use it

* open ``Point of sale >> Configuration >> Manual Credit Updates``
* create record or import csv, Excel file

Handling employees
------------------

Group of partner from the same Company can be handling together.

* Open wizard via ``Invoicing >> Sales >> Generate POS Credits Invoices``

  * Specify **Company**
  * Select **Credit Product** (create one if needed)
  * Select **Payment Type** -- way to compute **Credits to Add** for each employee
  * At employee list you can see **Current Credits** and check\edit **Credits to Add**
  * Click ``[Generate]``

* Open ``Invoicing >> Sales >>  Customer Invoices``
* Select Invoices for the same company
* Click ``[Action] -> Confirm Draft Invoices``
* Click ``[Action] -> Register Payment``
* Now Credits for employees are updated

Uninstallation
==============

Nothing special is needed to uninstall this module.
Debt data are still available after you re-install the module.
