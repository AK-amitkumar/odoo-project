==========================
 Print tweets with PosBox
==========================

The module allows to print tweets with specific hashtags by using PosBox.

TODO: Works with Network Printer only

Credits
=======

Contributors
------------
* `Dinar Gabbasov <https://it-projects.info/team/GabbasovDinar>`__

Sponsors
--------
* `IT-Projects LLC <https://it-projects.info>`__

Maintainers
-----------
* `IT-Projects LLC <https://it-projects.info>`__

Further information
===================

Demo: http://runbot.it-projects.info/demo/pos-addons/10

HTML Description: https://apps.odoo.com/apps/modules/10/printings_twitter_tweets/

Usage instructions: `<doc/index.rst>`_

Changelog: `<doc/changelog.rst>`_

Tested on Odoo 10.0 3550a68d968aeacf1b6efd1c96f5c57e5de60bbe
