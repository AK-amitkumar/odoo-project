`1.1.2`
-------

- **FIX:** Correct scrolling on the Payment screen on IOS

`1.1.1`
-------

- **FIX:** Compatibility with IOS 11.2
- **FIX:** Quantity indicator of products was not updated when quantity is changed via numpad
- **FIX:** Payment screen interface and ClientList screen interface

`1.1.0`
-------

- **NEW:** Payment screen interface
- **NEW:** Quantity indicator of products added to the current order
- **NEW:** Order list scrolling

`1.0.0`
-------

- Init version
