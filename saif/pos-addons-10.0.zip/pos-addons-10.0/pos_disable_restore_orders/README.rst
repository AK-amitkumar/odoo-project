Disable orders restoring
========================

The module disables restoring unpaid orders on startup.

Tested on Odoo pre-saas-6 46abcabd0ac1f993dd8763c72945b0546c42bcb5 (from https://github.com/odoo-dev/odoo/tree/8.0-pos-backports-rescue-fva )
