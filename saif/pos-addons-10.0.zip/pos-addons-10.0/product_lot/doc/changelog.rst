`1.0.2`
-------

- **Port:** Added support for version 10

`1.0.1`
-------

- **IMP** Support multi-stock configuration


`1.0.0`
-------

- Init version
