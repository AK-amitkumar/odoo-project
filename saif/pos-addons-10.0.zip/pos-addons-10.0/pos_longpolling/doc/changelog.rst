`2.0.0`
-------

- **NEW:** Support multiple buses with different channels for longpolling requests
- **NEW:** Additional longpolling connection status in POS interface

`1.1.1`
-------

- **FIX:** longpolling channel

`1.1.0`
-------

- **NEW:** longpolling connection status in POS interface

`1.0.0`
-------

- Init version
