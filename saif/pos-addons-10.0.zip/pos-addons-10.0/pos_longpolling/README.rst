=================
 POS Longpolling
=================

Technical module implement instant updates in POS

Credits
=======

Contributors
------------
* gabbasov@it-projects.info

Sponsors
--------
* `IT-Projects LLC <https://it-projects.info>`__

Further information
===================

Demo: http://runbot.it-projects.info/demo/pos-addons/10.0

HTML Description: https://apps.odoo.com/apps/modules/10.0/pos_longpolling/

Usage instructions: `<doc/index.rst>`__

Changelog: `<doc/changelog.rst>`__

Tested on Odoo 10.0 0cc09c773570d992d1fb3559e0d80acae3127ac7
