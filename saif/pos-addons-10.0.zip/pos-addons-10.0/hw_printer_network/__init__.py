# -*- coding: utf-8 -*-
def post_load():
    from . import controllers
