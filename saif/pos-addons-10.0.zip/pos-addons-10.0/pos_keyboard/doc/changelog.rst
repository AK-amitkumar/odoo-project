.. _changelog:

Updates
=======

`1.0.2`
-------

- Fix bug: Repeat last keystroke when press non-number key or non-shortcut key after keypress on the number or shortcut key (i.e. q15jj ended up as quantity 1555)

`1.0.1`
-------

- Fix barcode scanner bug
