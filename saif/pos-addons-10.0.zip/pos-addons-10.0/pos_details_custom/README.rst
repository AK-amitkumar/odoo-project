Custom Sale Details report
==========================

The module modifies report at Reporting\\Point of Sale\\Sale details. 
It replaces the products detail list by the total amount by product categories.

Tested on Odoo 8.0 d023c079ed86468436f25da613bf486a4a17d625
