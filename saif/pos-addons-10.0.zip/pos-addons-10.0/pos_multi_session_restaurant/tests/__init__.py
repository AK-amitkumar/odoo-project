# -*- coding: utf-8 -*-
from . import test_pos_ms_r
