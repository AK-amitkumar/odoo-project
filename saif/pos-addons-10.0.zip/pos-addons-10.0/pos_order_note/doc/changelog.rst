`1.1.1`
-------

- **NEW:** Support the POS Mobile UI for Waiters module

`1.0.1`
-------

- **FIX:** Issue about notes sync across POSes using pos_multi_session
- **FIX:** The selected notes cannot be printed on the order

`1.0.0`
-------

- Init version
