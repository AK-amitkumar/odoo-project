.. _changelog:

Updates
=======

`1.2.1`
------

- **NEW:** Support the POS Mobile UI for Waiters module

`1.1.1`
------

- **FIX:** ability to work in offline mode

`1.1.0`
______

- **NEW:** set discount program in customer form at POS
- **NEW:** set sequence for discount programs from tree view in backend

`1.0.0`
-------

- init version
