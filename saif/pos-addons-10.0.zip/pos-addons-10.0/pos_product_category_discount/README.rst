=======================
 POS Discount Programs
=======================

Set predefined discount programs for product categories in POS

Credits
=======

Contributors
------------
* gabbasov@it-projects.info

Sponsors
--------
* `Sinomate <http://sinomate.net/>`__

Maintainers
-----------
* `IT-Projects LLC <https://it-projects.info>`__

Further information
===================

Demo: http://runbot.it-projects.info/demo/pos-addons/10.0

HTML Description: https://apps.odoo.com/apps/modules/10.0/pos_product_category_discount

Usage instructions: `<doc/index.rst>`__

Changelog: `<doc/changelog.rst>`__

Tested on Odoo 10.0 3618e769aadf7e4e0ad0b26fa4f9861e27f99c57
