odoo.define('pos_restaurant.print_method', function (require) {
    "use strict";

    var models = require('pos_restaurant_base.models');
    var core = require('web.core');
    var QWeb = core.qweb;

    models.load_models({
        model: 'restaurant.printer',
        fields: ['printer_method_name'],
        domain: null,
        loaded: function(self,printers){
            self.printers.forEach(function(item){
                var printer_obj = _.find(printers, function(printer){
                    return printer.id === item.config.id;
                });
                item.config.printer_method_name = printer_obj.printer_method_name;
            });
        },
    });

    var OrderSuper = models.Order;
    models.Order = models.Order.extend({
        print_order_receipt: function(printer, changes) {
            var self = this;
            if ( changes.new.length > 0 || changes.cancelled.length > 0) {
                if (printer.config.printer_method_name === 'separate_receipt') {
                    var changes_new = $.extend({}, changes);
                    changes_new.new.forEach(function(orderline){
                        changes_new.cancelled = [];
                        changes_new.new = [orderline];
                        var receipt = QWeb.render('OrderChangeReceipt',{changes:changes_new, widget:self});
                        printer.print(receipt);
                    });
                    var changes_cancelled= $.extend({}, changes);
                    changes_cancelled.cancelled.forEach(function(orderline){
                        changes_cancelled.cancelled = [orderline];
                        changes_cancelled.new = [];
                        var receipt = QWeb.render('OrderChangeReceipt',{changes:changes_cancelled, widget:self});
                        printer.print(receipt);
                    });
                } else {
                    OrderSuper.prototype.print_order_receipt.apply(this, arguments);
                }
            }
        },
    });
});
