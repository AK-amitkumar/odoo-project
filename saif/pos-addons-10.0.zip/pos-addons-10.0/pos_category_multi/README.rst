========================================
 Multiple categories per product in POS
========================================

This module deactivate POS Categories field with many2one type and create new Categories field with many2many type which will be used instead.

Credits
=======

Contributors
------------
* Pavel Romanchenko <romanchenko@it-projects.info>

Sponsors
--------
* `twanda AG  <http://www.twanda.ch>`__

Further information
===================

HTML Description: https://apps.odoo.com/apps/modules/9.0/pos_category_multi/

Usage instructions: `<doc/index.rst>`__

Changelog: `<doc/changelog.rst>`__

Tested on Odoo 9.0 d3dd4161ad0598ebaa659fbd083457c77aa9448d
