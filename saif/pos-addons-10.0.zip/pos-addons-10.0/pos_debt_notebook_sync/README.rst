========================
 Internal Credit System
========================

The module allows to organize cash-free system for set of shops with a single payment point. E.g. at festivals, amusements parks, etc.

Credits
=======

Contributors
------------
* gabbasov@it-projects.info

Sponsors
--------
* `IT-Projects LLC <https://it-projects.info>`__

Further information
===================

Demo: http://runbot.it-projects.info/demo/pos-addons/10.0

HTML Description: https://apps.odoo.com/apps/modules/10.0/pos_debt_notebook_sync/

Usage instructions: `<doc/index.rst>`__

Changelog: `<doc/changelog.rst>`__

Tested on Odoo 10.0 6a7c05112bf0c07ffa7dadfe76be08f3121fd4c8
