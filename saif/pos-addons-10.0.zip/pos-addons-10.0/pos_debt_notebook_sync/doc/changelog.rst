`1.1.0`
-------

- **ADD:** Manual Credit Updates

`1.0.0`
-------

- Init version
