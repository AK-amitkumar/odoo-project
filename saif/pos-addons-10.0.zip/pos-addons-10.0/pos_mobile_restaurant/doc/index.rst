=======================
 POS Mobile Restaurant
=======================

Installation
============

* `Install <https://odoo-development.readthedocs.io/en/latest/odoo/usage/install-module.html>`__ this module in a usual way

Usage
=====

With using mobile telephone:

* Open menu ``Point of Sale``
* Click ``New Session``
* RESULT: POS interface in mobile version
* Use ``/pos/web/?m=0`` to force default POS interface

Without using mobile telephone:

* Open menu ``Point of Sale``
* Click ``New Session``
* RESULT: POS interface with default version
* Use ``/pos/web/?m=1`` to force the mobile version
