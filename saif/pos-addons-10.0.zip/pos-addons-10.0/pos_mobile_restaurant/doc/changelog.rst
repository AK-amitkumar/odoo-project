`1.2.2`
-------

- **IMP:** Scrolling type for IOS

`1.2.1`
-------

- **FIX:** Scrolling the tables on a floor screen on IOS

`1.2.0`
-------

- **FIX:** Compatibility with IOS 11.2
- **NEW:** Swiping for Floor screen
- **NEW:** Possibility set number of guests

`1.1.0`
-------

- **NEW:** Floor screen interface
- **NEW:** Functional part optimization
- **NEW:** Compatibility with pos_order_note, pos_order_cancel, pos_product_category_discount
- **NEW:** Ability to filter the products and partners in real-time

`1.0.0`
-------

- Init version
