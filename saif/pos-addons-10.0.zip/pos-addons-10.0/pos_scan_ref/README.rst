FIX searching product by ref in POS
===================================

Description: https://apps.odoo.com/apps/modules/8.0/pos_scan_ref
