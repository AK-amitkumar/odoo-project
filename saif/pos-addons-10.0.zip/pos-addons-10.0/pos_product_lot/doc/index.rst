===================
 Product lot in POS
===================

Installation
============

* `Install <https://odoo-development.readthedocs.io/en/latest/odoo/usage/install-module.html>`__ this module in a usual way


Configuration
=============

This module does not require configuration


Usage
=====

* Select the required quantity of goods in POS
* Click on ``[Unpack corresponding lot button]``
