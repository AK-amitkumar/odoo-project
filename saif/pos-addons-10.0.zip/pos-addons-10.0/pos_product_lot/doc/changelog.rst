`1.0.2`
-------

- **PORT** added Odoo 10 support

`1.0.1`
-------

- **FIX** spliting lot was lost if one click button quick enough
- **IMP** support multi-stock configuration
