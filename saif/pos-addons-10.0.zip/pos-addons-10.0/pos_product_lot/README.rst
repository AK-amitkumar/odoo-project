====================
 Product lot in POS
====================

The module allows to sell by boxes (lot) and open ones if needed and sell by pieces. After opening a box stock transaction will be created, so that you get minus one box and plus corresponding amount of items.

Credits
=======

Contributors
------------
* Ivan Yelizariev <yelizariev@it-projects.info>

Sponsors
--------
* `IT-Projects LLC <https://it-projects.info>`__

Maintainers
-----------
* `IT-Projects LLC <https://it-projects.info>`__

Further information
===================

HTML Description: Description: https://apps.odoo.com/apps/modules/10.0/pos_product_lot/

Usage instructions: `<doc/index.rst>`_

Changelog: `<doc/changelog.rst>`_
