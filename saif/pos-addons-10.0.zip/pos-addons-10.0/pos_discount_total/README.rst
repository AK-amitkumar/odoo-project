Discount for total amount of pos order
======================================

Description: https://apps.odoo.com/apps/modules/8.0/pos_discount_total/
