====================
 POS CASHIER SELECT
====================

Installation
============
* `Install <https://odoo-development.readthedocs.io/en/latest/odoo/usage/install-module.html>`__ this module in a usual way

Configuration
=============

The module doesn't need a special configuration.

Usage
=====

* Open POS session
* Create an order
* Click on ``[Payment]`` button to choose a cashier
* Select a cashier by scanning cashier's barcode or by clicking one from the list
