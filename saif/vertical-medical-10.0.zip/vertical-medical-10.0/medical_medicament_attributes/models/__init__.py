# -*- coding: utf-8 -*-
from . import medical_medicament
from . import medical_medicament_attribute_abstract
from . import medical_medicament_attribute_color
from . import medical_medicament_attribute_shape
from . import medical_medicament_attribute_flavor
