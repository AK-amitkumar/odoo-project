# -*- coding: utf-8 -*-
# Copyright 2016 LasLabs Inc.
# License LGPL-3.0 or later (http://www.gnu.org/licenses/lgpl.html).

from . import medical_pathology
from . import medical_pathology_category
from . import medical_pathology_code_type
