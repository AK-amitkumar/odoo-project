# -*- coding: utf-8 -*-
from . import product
from . import medical_drug_form
from . import medical_drug_route
from . import medical_medicament
