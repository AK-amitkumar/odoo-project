# -*- coding: utf-8 -*-
from . import medical_patient_occupation
from . import medical_patient
