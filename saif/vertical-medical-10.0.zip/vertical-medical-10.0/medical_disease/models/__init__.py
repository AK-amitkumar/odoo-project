# -*- coding: utf-8 -*-
from . import medical_patient_disease
from . import medical_pathology
from . import medical_pathology_category
from . import medical_pathology_group
from . import medical_patient
