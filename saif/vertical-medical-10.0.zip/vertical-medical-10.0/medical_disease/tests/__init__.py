# -*- coding: utf-8 -*-
from . import test_medical_disease
