# -*- coding: utf-8 -*-
# License LGPL-3.0 or later (http://www.gnu.org/licenses/lgpl.html).

from . import medical_abstract_entity
from . import medical_patient
from . import res_partner
