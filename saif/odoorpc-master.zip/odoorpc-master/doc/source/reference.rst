.. _reference:

Reference
=========

.. toctree::
    :maxdepth: 2

    ref_fields
    ref_odoorpc
    ref_odoo
    ref_db
    ref_report
    ref_models
    ref_env
    ref_rpc
    ref_session
    ref_tools
    ref_error

