SaaS portal sale
================

With this module you can sale SaaS


Tested on Odoo 9.0 901a3e030c4b11a219abf391839a471025bab4b3
