:main-title: Documentation
:banner: banners/home-bg.jpg

=====
Index
=====

.. todo:: what's the documentation's license?

.. rst-class:: index-tree
.. titlesonly breaks level 3 (~in-document) toc of left navbar, so use
   maxdepth instead
.. toctree::
    :maxdepth: 2

    setup
    usage
    demo
    api
    reference

.. ifconfig:: todo_include_todos

    .. rubric:: Things to add and fix

    .. todolist::
