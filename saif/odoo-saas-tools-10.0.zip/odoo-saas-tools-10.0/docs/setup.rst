:types: setting_up

==========
Setting Up
==========

.. toctree::
    :titlesonly:

    setup/install
    setup/dependencies
    setup/client
    setup/odoo-configuration
    setup/port_80
