===========================
 SaaS Sysadmin AWS Route53
===========================

This module is designed for use by another modules
such as saas_sysadmin_mailgun that is dependent
on AWS DNS servers fascility.

Credits
=======

Contributors
------------
* Ildar Nasyrov <Nasyrov@it-projects.info>
* Salton Massally <smassally@idtlabs.sl> (iDT Labs)

Sponsors
--------
* `IT-Projects LLC <https://it-projects.info>`__

Further information
===================

Usage instructions: `<doc/index.rst>`__

Changelog: `<doc/changelog.rst>`__

Tested on Odoo 9.0 4dafa2fcdf9131e38485b6816f8e425c7914db80
