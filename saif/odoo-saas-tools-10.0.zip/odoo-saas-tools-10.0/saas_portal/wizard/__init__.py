# -*- coding: utf-8 -*-
from . import config_wizard
from . import batch_delete
