SaaS Portal Backup
====================

This addon introduces the following functionalities

* Ability to backup database via a button on the UI
* Backs up database on deletion if specified
* Backs up database before upgrade if specified

Instructions
------------
Install a transport agent on server (e.g saas_server_backup_s3)
