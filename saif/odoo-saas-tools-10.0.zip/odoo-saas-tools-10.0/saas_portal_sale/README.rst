SaaS portal sale
================

With this module you can sale SaaS
There are attribute codes for SaaS products to be used as a parameters for client databases that are purchased.

SaaS attribute codes for SaaS products
--------------------------------------
* SUBSCRIPTION_PERIOD
* MAX_USERS

These codes should be assigned in Sales->Configuration->Product Categories & Attributes->Attributes.
Values for the codes should be assigned in Sales->Configuration->Product Categories & Attributes->Attribute Values.


Known issues
============

Tested on Odoo 9.0 901a3e030c4b11a219abf391839a471025bab4b3
