[![Build Status](http://runbot.it-projects.info/runbot/badge/flat/odoo-saas-tools/10.0.svg)](http://runbot.it-projects.info/demo/odoo-saas-tools/10.0)

Odoo SaaS Tools
==================

System to sale and manage odoo databases.

Main Project Website: https://it-projects-llc.github.io/odoo-saas-tools/

Getting Started: https://it-projects-llc.github.io/odoo-saas-tools/getting-started/

News: https://it-projects-llc.github.io/odoo-saas-tools/blog/ — [Subscribe by Email!](https://feedburner.google.com/fb/a/mailverify?uri=odoo-saas-tools&loc=en_US)

Documentation: https://odoo-saas-tools.readthedocs.io/
