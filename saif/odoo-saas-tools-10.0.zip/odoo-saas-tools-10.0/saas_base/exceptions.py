# -*- coding: utf-8 -*-
class MaximumDBException(Exception):
    pass


class MaximumTrialDBException(Exception):
    pass


class SuspendedDBException(Exception):
    pass
