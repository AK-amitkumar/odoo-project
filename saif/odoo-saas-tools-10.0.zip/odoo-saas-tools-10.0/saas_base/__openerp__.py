# -*- coding: utf-8 -*-
{
    'name': 'SaaS Base',
    'version': '0.0.1',
    'author': 'Cesar Lage',
    'license': 'LGPL-3',
    'category': 'SaaS',
    "support": "apps@it-projects.info",
    'website': 'https://it-projects.info',
    'depends': ['saas_utils'],
    'data': [],
    'installable': True,
}
