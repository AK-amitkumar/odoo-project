SaaS Base
=========

Base models to use in saas environment.

