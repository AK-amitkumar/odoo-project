SaaS Portal Tagging
===================

This addon introduces the following functionalities
* Ability to tag client databases
* Ability to tag plans which are copied on to clients spurned from that plan
