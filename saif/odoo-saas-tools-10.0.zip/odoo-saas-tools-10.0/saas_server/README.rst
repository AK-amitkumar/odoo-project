SaaS Server
===========

Module for central database on odoo databases cluster. Cluster is a odoo
installation. Each cluster is located on a separate server, in the main. 
