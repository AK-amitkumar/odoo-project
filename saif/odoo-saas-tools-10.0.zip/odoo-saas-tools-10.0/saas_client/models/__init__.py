# -*- coding: utf-8 -*-
from . import ir_configparameter
from . import res_user
from . import update
from . import res_config
