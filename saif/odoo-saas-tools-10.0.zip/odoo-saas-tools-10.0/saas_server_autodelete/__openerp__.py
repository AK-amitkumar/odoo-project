# -*- coding: utf-8 -*-
{
    'name': 'SaaS Server - Autodelete expired databases',
    'version': '1.0.0',
    'author': 'Ivan Yelizariev',
    'license': 'LGPL-3',
    'category': 'SaaS',
    "support": "apps@it-projects.info",
    'website': 'https://it-projects.info',
    'depends': ['saas_server'],
    'data': [
        'data/ir_cron.xml',
    ],
    'installable': True,
}
