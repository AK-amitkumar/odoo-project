
saas_sysadmin_route53
=====================
Integrates AWS Route53 with SAAS Portal so that domain records 
are managed when servers and clients are added or deleted from
saas portal


Usage
=====

1. Configure your AWS Credentials from Settings > Saas Portal Settings
