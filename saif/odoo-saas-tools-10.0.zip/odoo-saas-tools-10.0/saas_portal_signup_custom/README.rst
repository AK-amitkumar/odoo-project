======================================
 Create databases after signup custom
======================================

This is customization of saas_portal_signup module that allows to create several databases for new customers after signup.

Credits
=======

Contributors
------------
* Ildar Nasyrov <Nasyrov@it-projects.info>

Sponsors
--------
* `IT-Projects LLC <https://it-projects.info>`__

Maintainers
-----------
* `IT-Projects LLC <https://it-projects.info>`__

Further information
===================

Demo: http://runbot.it-projects.info/demo/REPO-NAME/BRANCH

HTML Description: https://apps.odoo.com/apps/modules/VERSION/TECHNICAL_NAME/

Usage instructions: `<doc/index.rst>`_

Changelog: `<doc/changelog.rst>`_

Tested on Odoo 8.0 c150838bb56ef4c08f2b2ccde3264ce42f9f42de
