# -*- coding: utf-8 -*-
from . import oauth_provider
