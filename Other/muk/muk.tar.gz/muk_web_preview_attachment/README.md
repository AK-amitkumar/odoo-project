# MuK Preview Attachment

Adds a button to the Attachment Sidebar to preview the content directly in the browser.
The module also enables the possibility to preview attachment in the Odoo Chat Widgets.