Changelog: 10/10/2015
======================

(Note: you need to restart Odoo and upgrade `web_rtl` and `report_rtl` inorder for changes to take effect)

- Adding Google's Droid Naskh as default display font.
- Fix distorted login screen (fixes issues #7)
- update README.rst file.
- various updates on css files.
