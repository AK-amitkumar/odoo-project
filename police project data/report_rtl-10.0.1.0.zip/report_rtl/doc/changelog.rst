Changelog: 10/10/2015
======================

(Note: you need to restart Odoo and upgrade `web_rtl` and `report_rtl` inorder for changes to take effect)

- Various improvements and bug fixes.
